<!doctype html> 
<html lang="en"> 
  <head> 
    
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1"> 
 
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
 
    <title>Hello, world!</title> 
  </head> 
  <body> 
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark"> 
      <div class="container-fluid"> 
        <a class="navbar-brand" href="adminindex.php">PHP CRUD OPERATION</a> 
        <div class="collapse navbar-collapse" id="navbarNav"> 
          <ul class="navbar-nav"> 
            <li class="nav-item"> 
              <a class="nav-link active" aria-current="page" href="index.php">Home</a> 
            </li> 
            
          </ul> 
        </div> 
      </div> 
    </nav> 
    <a type="button" class="btn btn-primary" href="admincreate.php">Add New</a> 

    <div class = "container my-4">
    <table class="table">
  <thead>
    <tr>
      <th >Customer ID</th>
      <th >First Name</th>
      <th >Last Name</th>
      <th >Email</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
  <?php
        include "connection.php";
        $sql = "select cus_id,First_name,Last_name,email from customer";
        $result = $conn->query($sql);
        if(!$result){
          die("Invalid query!");
        }
        while($row=$result->fetch_assoc()){
          echo "
      <tr>
        <th>$row[cus_id]</th>
        <td>$row[First_name]</td>
        <td>$row[Last_name]</td>
        <td>$row[email]</td>
        <td>
             <a class='btn btn-success' href='adminedit.php?cus_id=$row[cus_id]'>Edit</a>
             <a class='btn btn-danger' href='admindelete.php?cus_id=$row[cus_id]'>Delete</a>
                </td>
      </tr>
      ";
        }
      ?>
  </tbody>
    </table>
    </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>
<?php 
  include "connection.php"; 
  $cus_id=""; 
  $fname="";
  $lname="";
  $email=""; 
   
 
  $error=""; 
  $success=""; 
 
  if($_SERVER["REQUEST_METHOD"]=='GET'){ 
    if(!isset($_GET['cus_id'])){ 
      header("location:/loginsignup/adminindex.php"); 
      exit; 
    } 
    $cus_id = $_GET['cus_id']; 
    $sql = "select * from customer where cus_id=$cus_id"; 
    $result = $conn->query($sql); 
    $row = $result->fetch_assoc(); 
    while(!$row){ 
      header("location:/loginsignup/adminindex.php"); 
      exit; 
    } 
    $fname=$row["First_name"]; 
    $lname=$row["Last_name"]; 
    $email=$row["email"]; 
    
 
  } 
  else{ 
    $cus_id=$_POST["cus_id"];
    $fname=$_POST["fname"]; 
    $lname=$_POST["lname"];
    $email=$_POST["email"]; 
     
 
    $sql = "update customer set First_name='$fname', Last_name='$lname', email='$email' where cus_id='$cus_id'"; 
    $result = $conn->query($sql); 
     
  } 
   
?> 
<!DOCTYPE html> 
<html> 
<head> 
 <title>CRUD</title> 
 
  <meta name="viewport" content="width=device-width, initial-scale=1"> 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"> 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script> 
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script> 
</head> 
<body> 
<nav class="navbar navbar-expand-lg navbar-dark bg-dark" class="fw-bold"> 
      <div class="container-fluid"> 
        <a class="navbar-brand" href="adminindex.php">CUSTOMERS</a> 
        <div class="collapse navbar-collapse" id="navbarNav"> 
          <ul class="navbar-nav"> 
            <li class="nav-item"> 
              <a class="nav-link active" aria-current="page" href="index.php">Home</a> 
            </li> 
            <li class="nav-item"> 
              <a class="nav-link" href="admincreate.php">Add New</a> 
            </li> 
          </ul> 
        </div> 
      </div> 
    </nav> 
 <div class="col-lg-6 m-auto"> 
  
 <form method="post"> 
  
 <br><br><div class="card"> 
  
 <div class="card-header bg-warning"> 
 <h1 class="text-white text-center">  Update Member </h1> 
 </div><br> 
 
 <input type="hidden" name="id" value="<?php echo $cus_id; ?>" class="form-control"> <br> 
 
 <label> FIRST NAME: </label> 
 <input type="text" name="fname" value="<?php echo $fname; ?>" class="form-control"> <br> 

 <label> LAST NAME: </label> 
 <input type="text" name="lname" value="<?php echo $lname; ?>" class="form-control"> <br> 
 
 <label> EMAIL: </label> 
 <input type="email" name="email" value="<?php echo $email; ?>" class="form-control"> <br> 
 
 
 
 <button class="btn btn-success" type="submit" name="submit"> Submit </button><br> 
 <a class="btn btn-info" type="submit" name="cancel" href="adminindex.php"> Cancel </a><br> 
 
 </div> 
 </form> 
 </div> 
</body> 
</html>
<?php 
    include "connection.php"; 
    if(isset($_GET['cus_id'])){ 
        $cus_id =$_GET['cus_id']; 
        $sql = "delete from customer where cus_id=$cus_id"; 
        $conn->query($sql); 
    } 
    header('location:/loginsignup/adminindex.php'); 
    exit; 
?>